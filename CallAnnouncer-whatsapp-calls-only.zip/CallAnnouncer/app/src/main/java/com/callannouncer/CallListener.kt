package com.callannouncer

import android.app.Notification
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class CallListener : NotificationListenerService() {

    private val whatsappPackages = setOf("com.whatsapp", "com.whatsapp.w4b")

    // Phone (dialer / in-call UI) apps of common brands, plus a name check for unknown ones.
    private val phonePackages = setOf(
        "com.android.dialer", "com.google.android.dialer", "com.android.incallui",
        "com.android.server.telecom", "com.android.phone", "com.android.contacts",
        "com.samsung.android.incallui", "com.samsung.android.dialer",
        "com.huawei.contacts", "com.hihonor.contacts", "com.hihonor.incallui",
        "com.hihonor.dialer", "com.coloros.phone", "com.oneplus.dialer",
        "com.miui.voip", "com.android.incallui.oplus"
    )

    private fun isPhonePackage(pkg: String): Boolean =
        pkg in phonePackages || pkg.contains("incallui") || pkg.contains("dialer")

    private fun isEnabledFor(pkg: String): Boolean {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        return when {
            pkg in whatsappPackages -> prefs.getBoolean("announce_whatsapp", true)
            isPhonePackage(pkg) -> prefs.getBoolean("announce_phone", true)
            else -> false
        }
    }

    private companion object {
        // Notification.EXTRA_CALL_TYPE (API 31+); literal so it also compiles/runs on older versions.
        const val EXTRA_CALL_TYPE = "android.callType"
        const val CALL_TYPE_INCOMING = 1
    }
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private var activeKey: String? = null
    private var callerName = ""
    private var spokenCount = 0
    // Used to ignore re-posts of the same ringing notification, without depending on a
    // "removed" event (which Honor may miss when it freezes the app).
    private var lastKey: String? = null
    private var lastStart = 0L

    private val repeater = object : Runnable {
        override fun run() {
            if (activeKey == null || !ttsReady) return
            val max = getSharedPreferences("settings", MODE_PRIVATE).getInt("repeat_count", 2).coerceAtLeast(1)
            if (spokenCount < max) {
                speak()
                spokenCount++
                handler.postDelayed(this, 4000)
            } else {
                // Done announcing this call: free the voice engine and forget the active call,
                // so the next call is never blocked by stale state.
                activeKey = null
                releaseTts()
            }
        }
    }

    // Voice engine is created only when a call arrives and released when it ends.
    private fun startTts() {
        if (tts != null) return
        var engine: TextToSpeech? = null
        engine = TextToSpeech(this) { status ->
            handler.post {
                if (engine !== tts) {
                    engine?.shutdown()
                } else if (status == TextToSpeech.SUCCESS && activeKey != null) {
                    engine?.language = Locale.getDefault()
                    // Voice chosen in the app (if any); falls back to the default voice.
                    val chosen = getSharedPreferences("settings", MODE_PRIVATE).getString("voice_name", null)
                    if (chosen != null) {
                        try {
                            engine?.voices?.firstOrNull { it.name == chosen }?.let { engine?.voice = it }
                        } catch (_: Exception) {
                        }
                    }
                    engine?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    ttsReady = true
                    handler.removeCallbacks(repeater)
                    handler.post(repeater)
                } else {
                    releaseTts()
                }
            }
        }
        tts = engine
    }

    private fun releaseTts() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    // Same detection as the original working version: a call-category notification that has a
    // full-screen intent or 2+ buttons (Answer / Decline) is a ringing call.
    // Only extra rule: if Android says explicitly that it is an ongoing/screening call, ignore it.
    private fun isIncomingCall(n: Notification): Boolean {
        if (n.category != Notification.CATEGORY_CALL) return false
        val callType = n.extras.getInt(EXTRA_CALL_TYPE, 0)
        if (callType == 2 || callType == 3) return false
        return n.fullScreenIntent != null || (n.actions?.size ?: 0) >= 2 || callType == CALL_TYPE_INCOMING
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putLong("connected_at", System.currentTimeMillis()).apply()
    }

    // Saves a description of the last WhatsApp / phone notification so the app screen can show it.
    private fun recordDiagnostics(sbn: StatusBarNotification, incoming: Boolean) {
        val n = sbn.notification
        val time = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())
        val info = "$time  ${sbn.packageName}\n" + (if (incoming) "INCOMING CALL" else "not a ringing call") +
            "\ncategory=${n.category}  callType=${n.extras.getInt(EXTRA_CALL_TYPE, 0)}" +
            "\nactions=${n.actions?.size ?: 0}  fullScreen=${n.fullScreenIntent != null}" +
            "  timer=${n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)}" +
            "\nflags=${n.flags}  channel=${n.channelId}"
        getSharedPreferences("settings", MODE_PRIVATE).edit().putString("last_seen", info).apply()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg !in whatsappPackages && !isPhonePackage(pkg)) return
        val n = sbn.notification

        // Switched off in settings: ignore (and stop if it was already announcing).
        if (!isEnabledFor(pkg)) {
            if (sbn.key == activeKey) stopAnnouncing()
            return
        }

        val incomingNow = isIncomingCall(n)
        recordDiagnostics(sbn, incomingNow)

        if (incomingNow) {
            val now = android.os.SystemClock.elapsedRealtime()
            // Same notification re-posted while it is still ringing: already handled.
            if (sbn.key == lastKey && now - lastStart < 20000) return
            lastKey = sbn.key
            lastStart = now
            callerName = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Unknown"
            activeKey = sbn.key
            spokenCount = 0
            handler.removeCallbacks(repeater)
            releaseTts()   // always start from a fresh voice engine
            startTts()
        } else if (sbn.key == activeKey) {
            // Same notification changed to ongoing / answered.
            stopAnnouncing()
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.key == lastKey) lastKey = null
        if (sbn.key == activeKey) stopAnnouncing()
    }

    private fun speak() {
        val phrase = getSharedPreferences("settings", MODE_PRIVATE)
            .getString("phrase", "is calling") ?: ""
        val result = tts?.speak("$callerName $phrase".trim(), TextToSpeech.QUEUE_FLUSH, null, "call")
        val time = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("last_speak", "$time  announcement ${spokenCount + 1}, result=" +
                (if (result == TextToSpeech.SUCCESS) "OK" else "ERROR($result)"))
            .apply()
    }

    private fun stopAnnouncing() {
        handler.removeCallbacks(repeater)
        activeKey = null
        spokenCount = 0
        releaseTts()
    }

    // Honor/MagicOS may unbind the listener in the background; ask the system to bind it again.
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            requestRebind(ComponentName(this, CallListener::class.java))
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(repeater)
        releaseTts()
        super.onDestroy()
    }
}
