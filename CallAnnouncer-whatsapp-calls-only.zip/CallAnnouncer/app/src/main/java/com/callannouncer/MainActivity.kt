package com.callannouncer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingTest: String? = null
    private var statusView: TextView? = null

    private fun refreshStatus() {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val connectedAt = prefs.getLong("connected_at", 0L)
        val connected = if (connectedAt == 0L) "never" else
            java.text.SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(java.util.Date(connectedAt))
        statusView?.text = "Status\nNotification access: " + (if (enabled) "ON" else "OFF") +
            "\nListener last connected: $connected" +
            "\n\nLast call-related notification:\n" + (prefs.getString("last_seen", null) ?: "none seen yet")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        layout.addView(TextView(this).apply {
            text = "Call Announcer (WhatsApp + phone calls)\n\n" +
                "1. Enable notification access for this app.\n" +
                "2. Tap \"Allow background running\" and allow it.\n" +
                "3. On Honor/Huawei: tap \"Honor app launch settings\" and set this app to " +
                "manual, with Auto-launch, Secondary launch and Run in background all ON.\n" +
                "4. Open recent apps and lock this app (pull down on its card / lock icon)."
            textSize = 18f
        })

        layout.addView(Button(this).apply {
            text = "Enable notification access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        layout.addView(Button(this).apply {
            text = "Allow background running"
            setOnClickListener {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        })

        layout.addView(Button(this).apply {
            text = "Honor app launch settings"
            setOnClickListener { openVendorLaunchSettings() }
        })

        layout.addView(TextView(this).apply {
            text = "\nAnnounce calls from:"
            textSize = 16f
        })

        layout.addView(CheckBox(this).apply {
            text = "WhatsApp calls"
            isChecked = prefs.getBoolean("announce_whatsapp", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("announce_whatsapp", on).apply() }
        })

        layout.addView(CheckBox(this).apply {
            text = "Normal phone calls"
            isChecked = prefs.getBoolean("announce_phone", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("announce_phone", on).apply() }
        })

        layout.addView(TextView(this).apply {
            text = "\nText spoken after the caller name:"
            textSize = 16f
        })

        val phraseInput = EditText(this).apply {
            hint = "is calling"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("phrase", "is calling"))
        }
        layout.addView(phraseInput)

        layout.addView(TextView(this).apply {
            text = "\nHow many times to announce each call:"
            textSize = 16f
        })

        val countInput = EditText(this).apply {
            hint = "2"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("repeat_count", 2).toString())
        }
        layout.addView(countInput)

        layout.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                val count = (countInput.text.toString().toIntOrNull() ?: 2).coerceIn(1, 20)
                countInput.setText(count.toString())
                prefs.edit()
                    .putString("phrase", phraseInput.text.toString().trim())
                    .putInt("repeat_count", count)
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        layout.addView(Button(this).apply {
            text = "Test voice"
            setOnClickListener {
                speakTest("Ali " + phraseInput.text.toString().trim())
            }
        })

        statusView = TextView(this).apply { textSize = 13f; setPadding(0, 32, 0, 0) }
        layout.addView(statusView)

        layout.addView(Button(this).apply {
            text = "Refresh status"
            setOnClickListener { refreshStatus() }
        })

        layout.addView(Button(this).apply {
            text = "Reconnect listener"
            setOnClickListener {
                try {
                    NotificationListenerService.requestRebind(ComponentName(this@MainActivity, CallListener::class.java))
                    Toast.makeText(this@MainActivity, "Reconnect requested", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })

        setContentView(ScrollView(this).apply { addView(layout) })
    }

    // Honor / Huawei keep "App launch" (auto-start) in their own manager; try known screens, then fall back.
    private fun openVendorLaunchSettings() {
        val candidates = listOf(
            ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.appcontrol.activity.StartupAppControlActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")
        )
        for (c in candidates) {
            try {
                startActivity(Intent().setComponent(c))
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(
            this,
            "Open Settings > Battery > App launch > Call Announcer manually",
            Toast.LENGTH_LONG
        ).show()
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun speakTest(text: String) {
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
            return
        }
        pendingTest = text
        if (tts == null) {
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.getDefault()
                    ttsReady = true
                    pendingTest?.let { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "test") }
                    pendingTest = null
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
