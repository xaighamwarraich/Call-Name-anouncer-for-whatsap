package com.callannouncer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.speech.tts.Voice
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var statusView: TextView? = null
    private var voiceSpinner: Spinner? = null
    private var voiceList: List<Voice> = emptyList()
    private val whenTtsReady = mutableListOf<() -> Unit>()

    private fun refreshStatus() {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val connectedAt = prefs.getLong("connected_at", 0L)
        val connected = if (connectedAt == 0L) "never" else
            java.text.SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(java.util.Date(connectedAt))
        statusView?.text = "Status\nNotification access: " + (if (enabled) "ON" else "OFF") +
            "\nListener last connected: $connected" +
            "\nLast spoken: " + (prefs.getString("last_speak", null) ?: "never") +
            "\n\nLast call-related notification:\n" + (prefs.getString("last_seen", null) ?: "none seen yet")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        layout.addView(TextView(this).apply {
            text = "Call Announcer (WhatsApp + phone calls)\n\n" +
                "1. Enable notification access for this app.\n" +
                "2. Tap \"Allow background running\" and allow it.\n" +
                "3. On Honor/Huawei: tap \"Honor app launch settings\" and set this app to " +
                "manual, with Auto-launch, Secondary launch and Run in background all ON.\n" +
                "4. Open recent apps and lock this app (pull down on its card / lock icon)."
            textSize = 18f
        })

        layout.addView(Button(this).apply {
            text = "Enable notification access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        layout.addView(Button(this).apply {
            text = "Allow background running"
            setOnClickListener {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        })

        layout.addView(Button(this).apply {
            text = "Honor app launch settings"
            setOnClickListener { openVendorLaunchSettings() }
        })

        layout.addView(TextView(this).apply {
            text = "\nAnnounce calls from:"
            textSize = 16f
        })

        layout.addView(CheckBox(this).apply {
            text = "WhatsApp calls"
            isChecked = prefs.getBoolean("announce_whatsapp", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("announce_whatsapp", on).apply() }
        })

        layout.addView(CheckBox(this).apply {
            text = "Normal phone calls"
            isChecked = prefs.getBoolean("announce_phone", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("announce_phone", on).apply() }
        })

        layout.addView(TextView(this).apply {
            text = "\nVoice (tap to choose, it plays a sample):"
            textSize = 16f
        })

        voiceSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Loading voices...")
            )
        }
        layout.addView(voiceSpinner)

        layout.addView(TextView(this).apply {
            text = "\nText spoken after the caller name:"
            textSize = 16f
        })

        val phraseInput = EditText(this).apply {
            hint = "is calling"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("phrase", "is calling"))
        }
        layout.addView(phraseInput)

        layout.addView(TextView(this).apply {
            text = "\nHow many times to announce each call:"
            textSize = 16f
        })

        val countInput = EditText(this).apply {
            hint = "2"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("repeat_count", 2).toString())
        }
        layout.addView(countInput)

        layout.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                val count = (countInput.text.toString().toIntOrNull() ?: 2).coerceIn(1, 20)
                countInput.setText(count.toString())
                prefs.edit()
                    .putString("phrase", phraseInput.text.toString().trim())
                    .putInt("repeat_count", count)
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        layout.addView(Button(this).apply {
            text = "Test voice"
            setOnClickListener {
                speakTest("Ali " + phraseInput.text.toString().trim())
            }
        })

        statusView = TextView(this).apply { textSize = 13f; setPadding(0, 32, 0, 0) }
        layout.addView(statusView)

        layout.addView(Button(this).apply {
            text = "Refresh status"
            setOnClickListener { refreshStatus() }
        })

        layout.addView(Button(this).apply {
            text = "Reconnect listener"
            setOnClickListener {
                try {
                    NotificationListenerService.requestRebind(ComponentName(this@MainActivity, CallListener::class.java))
                    Toast.makeText(this@MainActivity, "Reconnect requested", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })

        setContentView(ScrollView(this).apply { addView(layout) })

        ensureTts { populateVoices(phraseInput) }
    }

    // Starts the voice engine once and runs the given action when it is ready.
    private fun ensureTts(action: () -> Unit) {
        if (ttsReady) {
            action()
            return
        }
        whenTtsReady.add(action)
        if (tts == null) {
            tts = TextToSpeech(this) { status ->
                runOnUiThread {
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale.getDefault()
                        ttsReady = true
                        val actions = whenTtsReady.toList()
                        whenTtsReady.clear()
                        actions.forEach { it() }
                    } else {
                        Toast.makeText(this, "Voice engine failed to start", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun applySavedVoice() {
        val saved = getSharedPreferences("settings", Context.MODE_PRIVATE).getString("voice_name", null)
        if (saved != null) {
            voiceList.firstOrNull { it.name == saved }?.let { tts?.voice = it }
        }
    }

    private fun populateVoices(phraseInput: EditText) {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val all = try { tts?.voices?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
        val offline = all.filter { !it.isNetworkConnectionRequired }
        voiceList = (if (offline.isNotEmpty()) offline else all)
            .sortedWith(compareBy({ it.locale.displayName }, { it.name }))

        val names = listOf("Default voice") + voiceList.map { "${it.locale.displayName} - ${it.name}" }
        val spinner = voiceSpinner ?: return
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)

        val saved = prefs.getString("voice_name", null)
        val index = voiceList.indexOfFirst { it.name == saved }
        spinner.setSelection(if (index >= 0) index + 1 else 0)

        var firstEvent = true
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (firstEvent) {
                    firstEvent = false
                    return
                }
                val edit = prefs.edit()
                if (position == 0) edit.remove("voice_name")
                else edit.putString("voice_name", voiceList[position - 1].name)
                edit.apply()
                if (position == 0) tts?.language = Locale.getDefault() else applySavedVoice()
                speakTest("Ali " + phraseInput.text.toString().trim())
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    // Honor / Huawei keep "App launch" (auto-start) in their own manager; try known screens, then fall back.
    private fun openVendorLaunchSettings() {
        val candidates = listOf(
            ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.appcontrol.activity.StartupAppControlActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")
        )
        for (c in candidates) {
            try {
                startActivity(Intent().setComponent(c))
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(
            this,
            "Open Settings > Battery > App launch > Call Announcer manually",
            Toast.LENGTH_LONG
        ).show()
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun speakTest(text: String) {
        ensureTts {
            applySavedVoice()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
