package com.callannouncer

import android.app.Notification
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class CallListener : NotificationListenerService() {

    private val whatsappPackages = setOf("com.whatsapp", "com.whatsapp.w4b")

    private companion object {
        // Notification.EXTRA_CALL_TYPE (API 31+); literal so it also compiles/runs on older versions.
        const val EXTRA_CALL_TYPE = "android.callType"
        const val CALL_TYPE_INCOMING = 1
    }
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private var activeKey: String? = null
    private var callerName = ""
    private var spokenCount = 0

    private val repeater = object : Runnable {
        override fun run() {
            if (activeKey == null || !ttsReady) return
            val max = getSharedPreferences("settings", MODE_PRIVATE).getInt("repeat_count", 2).coerceAtLeast(1)
            if (spokenCount < max) {
                speak()
                spokenCount++
                handler.postDelayed(this, 4000)
            } else {
                // Done announcing this call: free the voice engine but keep activeKey so the
                // same ringing notification is not announced again.
                releaseTts()
            }
        }
    }

    // Voice engine is created only when a call arrives and released when it ends.
    private fun startTts() {
        if (tts != null) return
        var engine: TextToSpeech? = null
        engine = TextToSpeech(this) { status ->
            handler.post {
                if (engine !== tts) {
                    engine?.shutdown()
                } else if (status == TextToSpeech.SUCCESS && activeKey != null) {
                    engine?.language = Locale.getDefault()
                    engine?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    ttsReady = true
                    handler.removeCallbacks(repeater)
                    handler.post(repeater)
                } else {
                    releaseTts()
                }
            }
        }
        tts = engine
    }

    private fun releaseTts() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    // True only for a WhatsApp notification that is an actual *ringing* call.
    // Messages, missed calls, "call in progress" and other WhatsApp notifications are ignored.
    private fun isIncomingCall(n: Notification): Boolean {
        // Never treat message / group-summary notifications as calls.
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return false

        val callType = n.extras.getInt(EXTRA_CALL_TYPE, 0)
        val isCallNotification = n.category == Notification.CATEGORY_CALL || callType != 0
        if (!isCallNotification) return false

        // Newer Android / WhatsApp use CallStyle, which says exactly what kind of call it is.
        if (callType != 0) return callType == CALL_TYPE_INCOMING

        // Fallback for older versions: ringing calls have a full-screen intent or
        // Answer + Decline buttons, and no running call timer (that means an ongoing call).
        val hasTimer = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
        if (hasTimer) return false
        return n.fullScreenIntent != null || (n.actions?.size ?: 0) >= 2
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in whatsappPackages) return
        val n = sbn.notification

        if (isIncomingCall(n)) {
            if (activeKey == sbn.key) return
            callerName = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Unknown"
            activeKey = sbn.key
            spokenCount = 0
            handler.removeCallbacks(repeater)
            if (ttsReady) handler.post(repeater) else startTts()
        } else if (sbn.key == activeKey) {
            // Same notification changed to ongoing / answered.
            stopAnnouncing()
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.key == activeKey) stopAnnouncing()
    }

    private fun speak() {
        val phrase = getSharedPreferences("settings", MODE_PRIVATE)
            .getString("phrase", "is calling") ?: ""
        tts?.speak("$callerName $phrase".trim(), TextToSpeech.QUEUE_FLUSH, null, "call")
    }

    private fun stopAnnouncing() {
        handler.removeCallbacks(repeater)
        activeKey = null
        spokenCount = 0
        releaseTts()
    }

    // Honor/MagicOS may unbind the listener in the background; ask the system to bind it again.
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            requestRebind(ComponentName(this, CallListener::class.java))
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(repeater)
        releaseTts()
        super.onDestroy()
    }
}
